module.exports = {
    apiKeys: [
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiY2hhbmdlVGhpc1VzZXJuYW1lIiwiaWF0IjoxNTY5ODM2NjY4fQ.evZa-Y2mup3UVb7Wzba8Qw7R9Q9PrsBjkDytO0YG-Qo',
        'secretapikey1',
    ],
    mstimeout: 15000,
    serverport: 3000
}
