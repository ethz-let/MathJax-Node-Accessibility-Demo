---------------------------------------------------------
Instruction for building a docker image
for the MathJax Rendering Service
---------------------------------------------------------

The following files are required:

- config.json     Change the values to match your server settings.
                  NOTE:
                  - the api-keys must be changed for production use.
                  - the port should be changed in production use.
- dockerfile      Dockerfile for the renderer, keep the name lowercase for compatibility to Mac.
- nodeApp.tar     Create the actual package that will be converted into a docker image.
                  nodeApp.tar contains the main application files of MathJax-Node-Accessibility-Demo,
                  so make sure to create a .tar with following contents:
                  - logs/*
                  - modules/*
                  - package.json
                  - server.js
                  - readme.md

---------------------------------------------------------
Create the docker image
---------------------------------------------------------

docker build -t mathjax-image .

---------------------------------------------------------
Run the image
---------------------------------------------------------

docker run -itd -p 3000:3000 --name mathjax-sample  mathjax-image  sh

---------------------------------------------------------
Test the services: hello service and example
Change API-Key if required
---------------------------------------------------------

curl -v --raw   http://localhost:3000/hello

curl -X POST \
     http://127.0.0.1:3000/process \
      -H 'API-Key: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiY2hhbmdlVGhpc1VzZXJuYW1lIiwiaWF0IjoxNTY5ODM2NjY4fQ.evZa-Y2mup3UVb7Wzba8Qw7R9Q9PrsBjkDytO0YG-Qo' \
      -H 'Content-Type: application/json' \
      -H 'cache-control: no-cache' \
      -d  '{"language":"de","html":{"key1":"<p>\\(e^{y^2/4} \\)<\/p>","key2":"<p>\\(\\sqrt{3}\\)<\/p>","key3":"<p>\\int_{a}\\)<\/p>","key4":"<p>\\(\\sum_{n=1}\\)<\/p>"}}'

--------------------------------------------------------
Run the test loop, change the loop variable if you wish
Change API-Key if required
--------------------------------------------------------

chmod +x ./testloop.sh
./testloop.sh

---------------------------------------------------------
Various
---------------------------------------------------------

# Login in to the docker instance
docker exec -it mathjax-sample sh

# Copy logs from container
docker cp mathjax-sample:/app/logs .