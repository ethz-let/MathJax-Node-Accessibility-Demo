#!/bin/bash
set -x
max=10
for (( i=1; i <= $max; ++i ))
do
  curl -X POST \
     http://localhost:3000/process \
      -H 'API-Key: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiY2hhbmdlVGhpc1VzZXJuYW1lIiwiaWF0IjoxNTY5ODM2NjY4fQ.evZa-Y2mup3UVb7Wzba8Qw7R9Q9PrsBjkDytO0YG-Qo' \
      -H 'Content-Type: application/json' \
      -H 'cache-control: no-cache' \
      -d  '{"language":"de","html":{"key1":"<p>\\(e^{y^2/4} \\)<\/p>","key2":"<p>\\(\\sqrt{3}\\)<\/p>","key3":"<p>\\int_{a}\\)<\/p>","key4":"<p>\\(\\sum_{n=1}\\)<\/p>"}}'

    echo "$i"
done
